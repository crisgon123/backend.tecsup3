﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
   interface IAnimal
   {
      string Nombre { get; set; }
      string Describir();
   }

   class Program
   {
      static void Main(string[] args)
      {
         Perro p1 = new Perro("Fido");
         Perro p2 = new Perro("Firulais");

         Gato g = new Gato("Tichondrius");

         p1.Ladrar();
         p2.Ladrar();
         g.Maullar();
         Entrenar(p1);
         Entrenar(g);

         IAnimal perrito = new Perro("Bulldog");

      }
      static void Entrenar(IAnimal animal)
      {
         Console.WriteLine($" {animal.GetType().ToString()} está entrenando");
      }
   }

   class Perro : IAnimal,IComparable
   {
      
      public string nombre { get; set; }
      public string Nombre{ get ; set; }

      public Perro(string nombre)
      {
         this.Nombre = nombre;
      }

      public void Ladrar()
      {
         Console.WriteLine("Guau! dijo {0}", nombre);
      }

      string IAnimal.Describir()
      {
         return "El perro se llama "+ nombre;
      }

      public int CompareTo(object obj)
      {
         return nombre.CompareTo(obj);
      }
   }

   class Gato : IAnimal
   {
      public string nombre { get; set; }
      public string Nombre { get ; set ; }

      public Gato(string nombre)
      {
         this.Nombre = nombre;
      }
      public void Maullar()
      {
         Console.WriteLine("Miau! dijo {0}", nombre);
      }
      string IAnimal.Describir()
      {
         return "El gato se llama " + nombre; ;
      }
   }

   
}
