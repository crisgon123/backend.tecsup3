﻿using ConsoleApp11.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
   class Persona : ITrabajador<Persona> , IEsposo
   {
      public int codigoTrabajador { get ; set ; }
      public int actaMatrimonio { get ; set ; }

      public void Trabajar()
      {
         
      }
      public void Caminar()
      {

      }
      public void Amar()
      {
         
      }
   }
}
