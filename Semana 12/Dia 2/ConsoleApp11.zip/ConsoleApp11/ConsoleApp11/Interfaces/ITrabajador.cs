﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11.Interfaces
{
   interface ITrabajador <T> where T : class
   {
      int codigoTrabajador { get; set; }
      void Trabajar();
   }
}
