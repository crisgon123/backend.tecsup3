﻿using ExtensionInterfaces.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionInterfaces
{
   class Calculadora : ICalculadoraCientifica
   {
      public int resultado { get; set; }

      public double Coseno(double a)
      {
         return Math.Cos(a);
      }

      public double Division(double a, double b)
      {
         return a/b;
      }

      public double Exp(double a)
      {
         return Math.Exp(a);
      }

      public double Log(double a)
      {
         return Math.Log10(a);
      }

      public double Multiplicacion(double a, double b)
      {
         return a*b;
      }

      public double Resta(double a, double b)
      {
         return a-b;
      }

      public double Seno(double a)
      {
         return Math.Sin(a); 
      }

      public double Sumar(double a, double b)
      {
         return a+b;
      }

      public double Tangente(double a)
      {
         return Math.Tan(a); ;
      }
   }
}
