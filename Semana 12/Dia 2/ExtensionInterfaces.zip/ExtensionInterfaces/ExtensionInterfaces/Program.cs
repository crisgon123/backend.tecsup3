﻿using ExtensionInterfaces.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionInterfaces
{
   class Program
   {
      static void Main(string[] args)
      {
         ICalculadoraCientifica miCalculadora = new Calculadora();
         var suma = miCalculadora.Sumar(4.0, 5.5);
         Console.WriteLine("La suma es: {0}",suma);
         var cos = miCalculadora.Coseno(30);
         Console.WriteLine("El coseno es: {0}", cos);
         var log = miCalculadora.Log(1.32);
         Console.WriteLine("El logaritmo es: {0}", log);

         ICalculadoraBasica nuevaCalc = new CalculadoraBasica();
         nuevaCalc.Multiplicacion(3.0, 6.0);
         nuevaCalc = new CalculadoraCientifica();
         


      }
   }
}
