﻿using ExtensionInterfaces.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionInterfaces
{
   class CalculadoraBasica : ICalculadoraBasica
   {
      public int resultado { get; set; }

      public double Division(double a, double b)
      {
         return a/b;
      }

      public double Multiplicacion(double a, double b)
      {
         return a * b;
      }

      public double Resta(double a, double b)
      {
         return a - b;
      }

      public double Sumar(double a, double b)
      {
         return a + b;
      }
   }
}
