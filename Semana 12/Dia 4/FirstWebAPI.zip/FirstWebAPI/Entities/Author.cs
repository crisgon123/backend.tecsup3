public class Author
{
  public int ID { get; set; }
  public string name { get; set; }
}