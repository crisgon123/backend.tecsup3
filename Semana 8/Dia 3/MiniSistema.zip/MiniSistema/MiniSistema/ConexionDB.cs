﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace MiniSistema
{
    class ConexionDB
    {
        SqlConnection con;
        public ConexionDB()
        {
            con = new SqlConnection();
            string cadenaDeConexion = "Data Source = CRISGON-TP\\SQLEXPRESS;" +
                "Initial Catalog = Tinder; Integrated Security = True";
            con.ConnectionString = cadenaDeConexion;
            
            //con = new SqlConnection("Data Source = CRISGON-TP\\SQLEXPRESS;" +
            //    "Initial Catalog = BikeStores; Integrated Security = True");
        }
        public SqlConnection GetConexion()
        {
            return con;
        }
        public void AbrirConexion()
        {
            try
            {
                con.Open();
                Console.WriteLine("Se abrió la conexion");
            }
            catch (Exception ex)
            {
                Console.WriteLine("No se pudo conectar a la base, motivo: {0}", ex.StackTrace);
            }

        }
        public void CerrarConexion()
        {
            try
            {
                con.Close();
                Console.WriteLine("Se cerró la conexion");
            }
            catch (Exception ex)
            {
                Console.WriteLine("No se pudo conectar a la base, motivo: {0}", ex.StackTrace);
            }
        }
    }
}

