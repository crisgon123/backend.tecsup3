﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioAntes.Entidades
{
    class Usuario
    {
        /// <summary>
        ///  prop crea get y set de propiedades
        ///  propfull crea get y set con funcionalidad añadida
        /// </summary>
        public string nombre { get; set; }
        public string clave { get; set; }
    }
}
