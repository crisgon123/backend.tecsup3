﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioAntes.Entidades;

namespace EjercicioAntes.Controladores
{
    class ControladorUsuario
    {
        ConexionDB con = new ConexionDB();
        SqlCommand cmd;
        public void InsertarUsuario (Usuario u)
        {
            cmd = new SqlCommand("insert into usuarios values (@nombre," +
                "@clave)", con.GetConexion());
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@nombre", u.nombre);
            cmd.Parameters.AddWithValue("@clave", u.clave);
            con.AbrirConexion();
            cmd.ExecuteNonQuery();
            con.CerrarConexion();
        }
        public void UpdateUsuario(Usuario u)
        {

        }
        public void CambiarContraseña(Usuario u)
        {

        }
        


    }
}
