﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MiniSistema.Controladores;
using MiniSistema.Entidades;

namespace MiniSistema
{
    public partial class Form2 : Form
    {
        ControladorUsuario cUsuario;
        private string textoForm1;
        // CREAMOS UN GET Y SET PARA RECIBIR UN ARGUMENTO
        // DE OTRA VENTANA
        public string Texto
        {
            get { return textoForm1; }
            set { textoForm1 = value; }
        }

        public Form2()
        {
            InitializeComponent();
            cUsuario = new ControladorUsuario();
        }
        // PASAR ARGUMENTOS (DATOS) A TRAVÉS DEL CONTRUCTOR
        public Form2(string texto)
        {
            InitializeComponent();
            textBox1.Text = texto;
            cUsuario = new ControladorUsuario();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidaContraseñas(textBox2.Text, textBox3.Text))
            {
                MessageBox.Show("Las contraseñas coinciden");
                cUsuario.RegistrarUsuario(new Usuario
                {
                    nombre_usuario = textBox1.Text,
                    clave = textBox2.Text
                });
            }
            else
                MessageBox.Show("Las contraseñas no coinciden");
        }

        private bool ValidaContraseñas(string a , string b)
        {
            if (a == b)
            {
                return true;
            }
            else
                return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // USANDO VARIABLE ESTÁTICA DE FORM1
            //textBox1.Text = Form1.nombreForm;

            // USANDO LA FUNCION TEXTO
            textBox1.Text = Texto;

        }
    }
}
