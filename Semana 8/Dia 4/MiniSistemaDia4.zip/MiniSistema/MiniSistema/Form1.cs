﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MiniSistema.Controladores;
using MiniSistema.Entidades;


namespace MiniSistema
{
    public partial class Form1 : Form
    {
        // USO DE VARIABLE ESTÁTICA PARA ENVIAR DATOS A
        // OTRO FORMULARIO
        public static string nombreForm;
        ControladorUsuario cUsuario;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cUsuario = new ControladorUsuario();
            
            //MessageBox.Show(textBoxUsuario.Text + "   " + textBoxPassword.Text);

            bool resultado = cUsuario.IngresarSistema(new Usuario
            {
                nombre_usuario = textBoxUsuario.Text,
                clave = textBoxPassword.Text
            });
            if (resultado)
            {
                MessageBox.Show("Se logeó correctamente");
                Form3 f2 = new Form3();
                f2.ShowDialog();
            }
            else
            {
                MessageBox.Show("No se pudo ingresar");
            }
        }
        
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // *******ENVÍO DE ARGUMENTOS A OTRA VENTANA******

            // ASIGNAMOS EL NOMBRE DE LA CAJA DE TEXTO A 
            // LA VARIABLE ESTÁTICA PARA USARLA EN OTOR LADO
            //nombreForm = textBoxUsuario.Text;

            // SE ENVÍA EL TEXTO DE LA CAJA DE TEXTO USUARIO
            // AL CONSTRUCTOR DE LA VENTANA HIJA (FORM2)
            //Form2 f2 = new Form2(textBoxUsuario.Text);

            Form2 f2 = new Form2();
            f2.Texto = textBoxUsuario.Text;
            f2.ShowDialog();
        }
    }
}
