﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SubirImagenFront.Helper;
using SubirImagenFront.Models;

namespace SubirImagenFront.Controllers
{
   public class HomeController : Controller
   {
      APIConnection apiCon = new APIConnection();
      public async Task<IActionResult> Index()
      {
         Usuario usu = new Usuario();
         HttpClient client = apiCon.Initial();
         HttpResponseMessage response = await client.GetAsync("api/images?nombre=Crisgon");
         if (response.IsSuccessStatusCode)
         {
            var result = response.Content.ReadAsStringAsync().Result;
            usu = JsonConvert.DeserializeObject<Usuario>(result);
            ViewData["nombre"] = usu.nombre;
            var img = Convert.ToBase64String(usu.imagen, 0, usu.imagen.Length);
            ViewData["image"] = img;
         }         
         return View();
      }

      public IActionResult Privacy()
      {
         return View();
      }

      [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
      public IActionResult Error()
      {
         return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
      }
   }
}
