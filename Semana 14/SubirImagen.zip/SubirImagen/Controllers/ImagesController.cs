﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SubirImagen.Controllers
{
   [Route("api/[controller]")]
   [ApiController]
   public class ImagesController : ControllerBase
   {
      private readonly Context context;

      public ImagesController(Context context)
      {
         this.context = context;
      }

      // GET api/values
      [HttpGet]
      public ActionResult<string[]> Get(string email)
      {
         return new string[] { "value1", "value2" };

      }

      // GET api/values/5
      [HttpGet("{id}")]
      public ActionResult<string> Get(int id)
      {
         return "value";
      }
      // 
      // POST api/images
      [HttpPost]
      public async Task<ActionResult> Post(IFormFile archivo)
      {
         // CREA USUARIO
         Usuario usuario = new Usuario();
         usuario.nombre = "Christian";

         // LECTURA DE ARCHIVO
         using (var memoryStream = new MemoryStream())
         {
            archivo.CopyTo(memoryStream);
            usuario.imagen = memoryStream.ToArray();
         }

         //GUARDAR EN BASE DE DATOS
         await context.Usuarios.AddAsync(usuario);
         await context.SaveChangesAsync();

         return Ok(usuario);
      }




      // PUT api/values/5
      [HttpPut("{id}")]
      public void Put(int id, [FromBody] string value)
      {
      }

      // DELETE api/values/5
      [HttpDelete("{id}")]
      public void Delete(int id)
      {
      }
   }
}
