﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using MiniSistema.Entidades;

namespace MiniSistema.Controladores
{
    class ControladorUsuario
    {
        ConexionDB con = new ConexionDB();
        SqlCommand cmd; 


        public bool IngresarSistema(Usuario u)
        {
            con.AbrirConexion();
            cmd = new SqlCommand("select count (*) from usuario where " +
                $"nombre_usuario = '{u.nombre_usuario}' and clave = '{u.clave}'", con.GetConexion());
            int resultado = Convert.ToInt32(cmd.ExecuteScalar());
            if (resultado == 1)
            {
                cmd = new SqlCommand("select nombre_usuario from usuario where " +
                $"nombre_usuario = '{u.nombre_usuario}' and clave = '{u.clave}'", con.GetConexion());
                string name = cmd.ExecuteScalar().ToString();
                con.CerrarConexion();
                return true;

            }
            else
             
                return false;
        }
        public bool RegistrarUsuario(Usuario u)
        {
            con.AbrirConexion();
            cmd = new SqlCommand("insert into usuario values " +
                $"('{u.nombre_usuario}','{u.clave}')", con.GetConexion());
            cmd.ExecuteNonQuery();
            con.CerrarConexion();
            return true;

        }


    }
}
