﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniSistema
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("ID", "ID");
            dataGridView1.Columns.Add("Items", "Productos");

            comboBox1.Items.Add("Gato");
            comboBox1.Items.Add("Sin genero");



            // TODO: esta línea de código carga datos en la tabla 'bikeStoresDataSet2.staffs' Puede moverla o quitarla según sea necesario.
            this.staffsTableAdapter.Fill(this.bikeStoresDataSet2.staffs);
            // TODO: esta línea de código carga datos en la tabla 'bikeStoresDataSet1.customers' Puede moverla o quitarla según sea necesario.
            this.customersTableAdapter.Fill(this.bikeStoresDataSet1.customers);
            // TODO: esta línea de código carga datos en la tabla 'bikeStoresDataSet1.customers' Puede moverla o quitarla según sea necesario.
            this.customersTableAdapter.Fill(this.bikeStoresDataSet1.customers);
            

        }
        int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {

            //label1.Text = Convert.ToString( DateTime.Now);
            i++;
            label1.Text = Convert.ToString(i);
        }
        int flag = 1;
        private void button1_Click(object sender, EventArgs e)
        {
            if (flag == 1)
            {
                timer1.Stop();
                flag = 0;
            }
            else
            {
                timer1.Start();
                flag = 1;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox1.SelectedIndex;
            labelIndice.Text = Convert.ToString(index);
            labelContenido.Text = comboBox1.Items[index].ToString();
        }
        int index = 0;
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            index = dataGridView1.Rows.Add();
            dataGridView1.Rows[index].Cells[0].Value = Convert.ToString(i);
            dataGridView1.Rows[index].Cells[1].Value = textBoxItem.Text;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.RemoveAt(index);
        }

        
    }
}
