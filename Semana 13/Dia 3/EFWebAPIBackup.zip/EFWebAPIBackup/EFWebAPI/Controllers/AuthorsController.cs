﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using EFWebAPI.EFContext;
using EFWebAPI.Entities;
using EFWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;

namespace EFWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorsController : ControllerBase
    {
      private readonly EFWebAPIContext context;
      private readonly IMapper mapper;

      public AuthorsController(EFWebAPIContext context, IMapper mapper)
      {
         this.context = context;
         this.mapper = mapper;
      }

      [HttpGet("relacionar/{idAuthor}/{idBook}")]
      public ActionResult<Book> Relacionar (int idAuthor , int idBook)
      {
         var author = context.Authors.Find(idAuthor);
         var book = context.Books.Find(idBook);
         book.Author = author;
         context.Entry(book).State = EntityState.Modified;
         context.SaveChanges();
         return Ok(book);
      }

      [HttpPost]
      public async Task<ActionResult> Post([FromBody] Author author)
      { 
         await context.AddAsync(author);
         context.SaveChanges();
         return new CreatedAtRouteResult("GetAuthor", new { id = author.ID }, author);
      }

      [HttpGet("{id}", Name = "GetAuthor")]
      public ActionResult<AuthorDTO> Get(int id)
      {
         var author = context.Authors.Find(id);

         if (author == null)
            return BadRequest(id);

         var authorDTO = mapper.Map<AuthorDTO>(author);
         return authorDTO;
      }

      [HttpGet]
      public ActionResult<IEnumerable<Author>> Get()
      {
         var authors = context.Authors.Include(x=>x.Books).ToList();
         var authorsDTO = mapper.Map<List<AuthorDTO>>(authors);
         return Ok(authorsDTO);

      }

      

      [HttpPut]
      public ActionResult Put([FromBody] Author author )
      {
         // if (author == null)
         //   return BadRequest();

         context.Entry(author).State = EntityState.Modified;
         context.SaveChanges();
         return Ok();
      }

      // ACTUALIZA UN RECURSO USANDO UN JSONPATCHDOCUMENT
      [HttpPatch("{id}")]
      public async Task<ActionResult> Patch (int id, [FromBody] JsonPatchDocument<Author> patchDocument)
      {
         if (patchDocument == null)
            return BadRequest();
         var author = await context.Authors.FirstOrDefaultAsync(x => x.ID == id);
         if (author == null)
            return NotFound();

         // SE APLICAN LOS CAMBIOS AL AUTOR ENCONTRADO
         patchDocument.ApplyTo(author, ModelState);
         // SE VALIDA QUE TODAS LAS REGLAS ESTÉN SIENDO RESPETADAS
         if (TryValidateModel(author))
         {
            await context.SaveChangesAsync();
            return NoContent(); // return Ok();
         }
         else
            return BadRequest(ModelState);
      }

      [HttpPut("UpdateName")]
      public ActionResult Put([BindRequired]int id, [BindRequired] string newName)
      {
         var author = context.Authors.Find(id);
         if (author == null)
            return BadRequest();

         author.name = newName;
         context.Entry(author).State = EntityState.Modified;
         context.SaveChanges();
         return Ok();
      }

      // BORRA UN ELEMENTO DEL RECURSO AUTHORS
      [HttpDelete("{id}")]
      public async Task<ActionResult> Delete (int id)
      {
         /*  OTRA FORMA DE BORRAR, SELECCIONAMOS SOLO EL ID 
          *  Y HACEMOS EL BORRADO CREANDO UN NUEVO AUTOR PONIENDO EL
          *  ID OBTENIDO
           
         var authorID = await context.Authors.Select(x => x.ID)
            .FirstOrDefaultAsync(x => x == id);
         context.Authors.Remove(new Author { ID = authorID });
         */
         var author = await context.Authors.FirstOrDefaultAsync(x => x.ID == id);
         if (author == null)
            return BadRequest();
         context.Authors.Remove(author);
         await context.SaveChangesAsync();

         return NoContent();
      }

   }
}