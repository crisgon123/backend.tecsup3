﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationJWT.AuthModels
{
   public class Login
   {
      public string username { get; set; }
      public string password { get; set; }
   }
}
