﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VersionamientoAPI.Entities
{
   public class Author
   {
      public int ID { get; set; }
      public string name { get; set; }
      
   }
}
